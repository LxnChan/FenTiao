Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("WaveForm Example")> 
<Assembly: AssemblyDescription("Uses BASS .NET Library")> 
<Assembly: AssemblyCompany("ActiveASP Software")> 
<Assembly: AssemblyProduct("WaveForm Example")> 
<Assembly: AssemblyCopyright("Copyright � 2006 ActiveASP Software. All rights reserved.")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("01776D52-3FF3-450C-A533-D8751EA4B74A")>  
'<Assembly: AssemblyKeyFileAttribute("C:\activeasp.snk")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
